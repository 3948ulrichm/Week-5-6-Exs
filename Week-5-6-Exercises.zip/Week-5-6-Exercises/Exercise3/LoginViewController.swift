//
//  LoginViewController.swift
//  Exercise3
//
//  Created by Michael Ulrich on 10/8/17.
//  Copyright © 2017 Michael Ulrich. All rights reserved.
//


import UIKit
import FirebaseAuth // TODO: 1. Add the first Firebase import


class LoginViewController: UIViewController {
    
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var container: UIView!
 
    func btnLogin_TouchUpInside(_ sender: Any) {
        // NOTE: When user signs into app, pass the user's email address and password to signInWithEmail:email:password:completion:
        
        // TODO: perform some input validation here
        // check if the fields are not nil by using conditional binding
        
        if let email = txtEmail.text, let password = txtPassword.text
        {
            Auth.auth().signIn(withEmail: email,password:password){(user,error) in
                //if the sign in is successful, we should have a valid "user" value
                if user != nil {
                    //user is found go to Weather page, present it modeally (no back button)
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "welcome")
                    //in this case, "welcome" should be your landing pages' story id
                    self.present(vc!, animated: true, completion: nil)
                }
                else{
                    // TODO: Check error and show error message, use the example of regsitration page
                }
                
            }
        }
    }



override func viewDidLoad() {
    super.viewDidLoad()
    
    // Do any additional setup after loading the view.
}

override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
}

override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
    txtEmail.resignFirstResponder()
    txtPassword.resignFirstResponder()
}
}

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
