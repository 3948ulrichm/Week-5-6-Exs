//
//  RegisterViewController.swift
//  Exercise3
//
//  Created by Michael Ulrich on 10/8/17.
//  Copyright © 2017 Michael Ulrich. All rights reserved.
//

import UIKit
import FirebaseAuth

class RegisterViewController: UIViewController {

    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var btnRegister: UIButton!
    @IBOutlet weak var container: UIView!
    
    @IBAction func btnRegister_TouchUpInside(_ sender: Any) {
    // TODO: perform some input validation here
    // check if the fields are not nil by using conditional binding
    if let email = txtEmail.text, let password = txtPassword.text //, let name = txtName.text
        {
            //Use the same code from website (LINK IN APPENDIX)
            //Create a new accouynt by passing the new user's email address and password to createUserEmail:email:password:completion
    
    Auth.auth().signIn(withEmail: email, password: password) { (user, error) in
    // ...
    // if the registration is successful then we should have a valid user value
    if user != nil {
        // user is found go to the Weather screen
        let vc = self.storyboard?.instantiateViewController(withIdentifier:"welcome")
        self.present(vc!, animated:true, completion:nil)
    }
    else{
        // check error and show an error message
        let alertController = UIAlertController(title:"Registration Failed!", message: (error?.localizedDescription)!, prefferedStyle: UIAlertControllerStyle.default){
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default){
        (result : UIAlertAction) -> Void in
        print("OK")
        }
            
//        alertController.addAction(okAction)
//        self.present(alertController, animated: true, completion: nil)
    
        }
    }
        }
    }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        txtName.resignFirstResponder()
        txtEmail.resignFirstResponder()
        txtPassword.resignFirstResponder()
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
