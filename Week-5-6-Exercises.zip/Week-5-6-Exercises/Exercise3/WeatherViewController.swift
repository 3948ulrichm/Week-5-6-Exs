//
//  WeatherViewController.swift
//  Exercise3
//
//  Created by Michael Ulrich on 10/8/17.
//  Copyright © 2017 Michael Ulrich. All rights reserved.
//

import UIKit
import FirebaseAuth

class WeatherViewController: UIViewController {

    
    @IBOutlet weak var lblWelcome: UILabel!
    @IBOutlet weak var lblWeather: UILabel!
    @IBOutlet weak var btnSunny: UIButton!
    @IBOutlet weak var btnFoggy: UIButton!
//
//    //Monitoring Authentication: Read (LINK IN APPENDIX C)
//    //Check if the user authentication is authorized: if logged in skip the loggin screen
//    
//    //create a reference with a connection to the realtime Firebase Db
//    //create a child node for your table in the JSON document
//    
//    let weatherNodeRef = FIRDatabase.database().reference().child("weatherCondition")
//    
//    
//    // add a viewDidAppear function override for listening and fetching data from the realtime database
//    
//    override func viewDidAppear(_ animated: Bool) {
//        //listen/observe database value changes
//        weatherNodeRef.observe(.value, with: {(snapshot:FIRDataSnapshot) in
//            //synchronize and map the updated Db values under this child node to the lblWeather controller
//            self.lblWeather.text = snapshot.value as AnyObject;).debugDescription
//        })
//    }

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
//    @IBAction func btnFoggy_TouchUpInside(_ sender: Any) {
//        weatherNodeRef.setValue("Foggy")
//    }
//    
//    @IBAction func btnSunny_TouchUpInside(_ sender: Any) {
//        weatherNodeRef.setValue("Sunny")
//    }
//    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
